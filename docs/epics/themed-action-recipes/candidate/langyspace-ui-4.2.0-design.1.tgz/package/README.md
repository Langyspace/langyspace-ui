# @langyspace/ui

Componentes React compartilhados pelos cinco produtos Langy.space. Cada componente tem uma responsabilidade de apresentação ou interação; o produto fornece conteúdo, dados e ações.

A versão **4.1.0** mantém os contratos do React 19, o tema compartilhado e as props da major 4. Ela padroniza a autoria com styled-components e acrescenta a auditoria de estilos. Consulte a [migração para 4.0](docs/components/migration-v4.md). O histórico de organização por responsabilidade e retirada de APIs está na [migração para 3.0](docs/components/migration-v3.md); para adoções anteriores à major 2, consulte a [migração para 2.0](docs/components/migration-v2.md).

## Instalação

Após a publicação e conferência do checksum, instale o artefato imutável da release 4.1.0:

```bash
pnpm add styled-components@^6.4.0 '@langyspace/ui@https://github.com/Langyspace/langyspace-ui/releases/download/v4.1.0/langyspace-ui-4.1.0.tgz'
```

Durante a preparação, valide pelo candidato imutável identificado na entrega, com sua integridade registrada. Os produtos mantêm a dependência oficial anterior até a nova release existir e seu checksum ser conferido. Não usar uma branch móvel ou um link local na dependência entregue.

React/React DOM19 e styled-components6 são peers; react-hook-form7 é peer opcional, usado só por `@langyspace/ui/form`. Não há import obrigatório de CSS nem ThemeProvider externo. As ações leem o tema do ThemeProvider quando fornecido e usam o `theme` exportado como fallback. Os produtos usam o mesmo `theme` e o `GlobalStyles` da UI no próprio ThemeProvider. A tipografia herda a fonte do produto. Algumas famílias têm composição própria documentada, como FlashcardFrame e seus filhos.

## Como o código deve ser lido

```tsx
import { ActionLink, Button } from '@langyspace/ui'

interface RecordActionsProps {
  listHref: string
  onSave: () => void
  saving: boolean
}

export function RecordActions({
  listHref,
  onSave,
  saving,
}: RecordActionsProps) {
  return (
    <>
      <Button loading={saving} onClick={onSave}>
        Salvar
      </Button>
      <ActionLink href={listHref} variant="secondary">
        Voltar
      </ActionLink>
    </>
  )
}
```

Comandos usam Button; navegação usa ActionLink ou um link semântico da família. Props nativas, refs e nomes acessíveis continuam no elemento correspondente. O exemplo não depende de um schema de renderização ou de flags por projeto.

Use children para conteúdo aberto e slots para regiões estáveis. Coleções de opções, ações, linhas e barras continuam como dados quando essa é a responsabilidade do componente. A biblioteca não implementa roteamento, fetching, permissões, billing, calendário de negócio ou persistência.

## Catálogo

O [índice de componentes](docs/components/index.md) liga cada export ao guia, à implementação e aos tipos. Os guias mostram propósito, contrato, composição e cuidados específicos.

| Família                                  | Guia                                                                 |
| ---------------------------------------- | -------------------------------------------------------------------- |
| Ações, campos e formulários              | [Escolha e composição](docs/components/controls.md)                  |
| Autenticação, identidade e documentos    | [Fluxos e anatomia](docs/components/auth-brand-documents.md)         |
| Estados, superfícies, listas e métricas  | [Composição de dados](docs/components/data-feedback.md)              |
| Navegação, menus, modais e mensagens     | [Interação e foco](docs/components/navigation-overlays-messaging.md) |
| Calendário e disponibilidade             | [Datas preparadas pelo produto](docs/components/calendar.md)         |
| Flashcards, quiz, shadowing e resultados | [Composição de prática](docs/components/practice.md)                 |

Não unifique contratos só porque se parecem. MetricSummary e StatCard, por exemplo, têm hierarquias diferentes. Não mantenha um export sem responsabilidade ou uso comprovado; remoções e mudanças incompatíveis têm migração e SemVer explícitos.

## Estilos e contexto

A apresentação autoral usa definições tagged de styled-components. `pnpm run test:styling-system` verifica também as stories e os fixtures vivos do catálogo: CSS/Sass/Less autoral, style em JSX/HTML, attrs de estilo e escritas diretas de CSS no DOM bloqueiam a entrega. Imports de folhas de fontes do pacote Fontsource são permitidos. HTML gerado pelo styled-components exige manifesto com origem, commit e hashes conferidos; marcar uma pasta como vendor não é uma exceção.

Nos produtos, execute `langyspace-styling-audit scripts/styling-system.audit.config.mjs` como parte da qualidade de código. A ferramenta usa TypeScript >=5.9 e <7 como peer opcional; o runtime dos componentes não carrega TypeScript. O CSS final gerado pelo styled-components continua sendo entregue ao navegador normalmente.

Tokens e receitas existentes concentram valores compartilhados. Geometria contextual pode permanecer local quando padronizá-la mudaria a interface. Não aproximar cores, trocar px por rem ou acrescentar uma prop para cada diferença de layout.

FieldRoot fornece associação de identificação/feedback; CompoundControl possui a superfície composta. FlashcardFrame fornece as variáveis da família e FlashcardFlip controla a face acessível. Dialog/Drawer compartilham ModalLayer privado. Esses contratos estão nos respectivos guias.

O produto adapta seu Router e mantém a geometria de página quando necessário. Ele não importa styles internos da biblioteca, monta classes privadas de anatomia ou depende da ordem de importação de CSS.

## SSR e hidratação

Em Vite, inclua a biblioteca e styled-components na mesma coleta de estilos do servidor:

```ts
export default defineConfig({
  ssr: { noExternal: ['styled-components', '@langyspace/ui'] },
})
```

Mantenha versões únicas dos peers no consumidor. A modalidade de Dialog/Drawer também é ativada quando uma camada inicialmente aberta é hidratada; abrir o portal não basta para provar foco, inércia e bloqueio de rolagem.

## Encontrar um componente no checkout

O código usa nomes de componentes React e famílias de responsabilidade:

```text
src/
  components/
    Button/Button.tsx
    Calendar/ScheduleCalendar.tsx
    Calendar/MonthView.tsx
    Auth/AuthFrame.tsx
    Form/TextInput.tsx
    Form/CardDetailsFields.tsx
    MetricSummary/MetricSummary.tsx
    StatCard/StatCard.tsx
    PracticeResultPanel/PracticeResultPanel.tsx
  foundations/    tema, receitas e contratos compartilhados
  internal/       hooks, contextos e infraestrutura privada
  index.ts        API pública
  form.ts         entrada com react-hook-form
stories/          exemplos e estados do catálogo
test/             comportamento, contratos de tipos e setup
```

Cada componente separa responsabilidades: `Button.tsx` contém só React,
`Button.types.ts` os tipos públicos e `Button.styles.ts` os estilos styled-components,
que leem o `theme` de `foundations/theme`. O ESLint impõe essa divisão; a dívida
restante fica em `eslint-suppressions.json` e só pode diminuir.
Exemplos ficam em stories e testes em test, separados da implementação.
Componentes simples podem usar um único arquivo. Não há classificação atomic nem
uma pasta para cada detalhe. A major retira adaptadores já substituídos; os componentes completos possuem sua anatomia privada.

```tsx
<MetricSummary value={correctAnswers} label="Acertos" />
<StatCard value={activeStudents} label="Alunos ativos" tone="brand" />
<PracticeResultPanel heading="Resultado" description={summary} actions={actions}>
  {metrics}
</PracticeResultPanel>
```

As mudanças de contrato estão no [guia da v4](docs/components/migration-v4.md); o guia da major 3 continua como histórico. O guia [de estrutura](docs/epics/ui-library-component-simplification/structure-plan.md)
registra o escopo e os limites desta reorganização.

O manifest em quality/component-manifest.ts liga export, owner, props, guia, story, teste e exemplos de consumidores. O comando é uma ferramenta do repositório:

```bash
node scripts/query-component-reference.mjs ScheduleRow
node scripts/query-component-reference.mjs ScheduleRow --workspace /caminho/dos/checkouts
```

O diretório informado contém os checkouts com os nomes dos repositórios. A verificação segue imports, reexports e composição React/styled até o JSX. Ela verifica uma relação de fonte; não prova que uma rota foi exercitada ou publicada.

## Desenvolvimento e revisão

Use pnpm e o Node definido em package.json. Faça a menor verificação que detecta o risco da alteração e consulte o AGENTS.md antes da entrega. CI mantém os gates amplos.

Toda mudança pública atualiza tipos, exemplos, manifest e snapshot de API. Novos componentes precisam de responsabilidade e reutilização demonstradas, stories de estados pertinentes e cobertura de comportamento. Pacotes têm build, budgets e smoke ESM/SSR/browser reais; nenhum orçamento é relaxado para acomodar uma refatoração.

Mudanças visuais têm PR com imagens Antes/Depois lado a lado e aprovação humana da revisão atual. Os planos e decisões desta evolução ficam em docs/epics/ui-library-react-craftsmanship.

### Dados do cartão

CardDetailsFields mantém valores numéricos sem pontuação em value/onChange e aplica máscara ao
telefone brasileiro, com ou sem +55. O slot opcional phoneField substitui apenas esse controle para
consumidores que já conhecem país/telefone do cadastro. O consumidor controla esse valor, valida o
formulário e fornece o campo com nome, rótulo e required. A biblioteca não persiste dados nem chama
o provedor de pagamentos.

## Candidato de tema para revisão

A revisão `4.2.0-design.1` corrige as receitas existentes de Button, ActionLink e IconButton para
respeitarem `buttons`, `typography`, `radius` e demais tokens já públicos do ThemeProvider. A API de
props/exports continua a mesma; o tema padrão é usado sem provider. As capturas e a origem do
candidato estão em `docs/epics/themed-action-recipes/`. Esse candidato depende do trabalho UI 4.1 e não substitui a release oficial
para integração final nem autoriza publicação.

O candidato de tema acrescenta `theme.dialog` para apresentação suportada do Dialog e completa as
receitas de ações, incluindo borda, hover, texto e foco. Use `createTheme` para criar um tema completo;
ThemeProvider transmite seus valores também aos portais React. CSS de página, conteúdo, rotas e
estado do domínio ficam no produto. Não sobrescreva classes privadas da biblioteca para alterar pele,
fontes ou medidas de seus componentes. As chaves são aditivas; props existentes são preservadas e `closeIcon` é um slot opcional.
